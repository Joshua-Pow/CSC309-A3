from django.contrib import admin
from .models import Paragraph

# Register your models here.
admin.site.register(Paragraph)